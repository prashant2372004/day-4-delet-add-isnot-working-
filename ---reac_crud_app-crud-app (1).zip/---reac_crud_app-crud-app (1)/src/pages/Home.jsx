import axios from 'axios'
import React, { useEffect, useState } from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

import 'bootstrap/dist/css/bootstrap.min.css'


const Home = () => {

    const [user, setUser] = useState();
    const [editableUser, setEditableUser] = useState()
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const fetchUser = async () => {
        try {
            const response = await axios("https://fakestoreapi.com/users");
            if (response?.status === 200) {
                setUser(response?.data)
            } else {
                console.log("Found Error");
            }
        } catch (error) {
            console.log(error);
        }
    }

    const handleEditOpen = (id) => {
        const response = user?.find((user) => user.id === id)
        setEditableUser(response)
        handleShow()
    }

    const handleDelete = (id) => {
        const response = user?.filter((user) => user?.id !== id)
        setUser(response)
    }

    const handleEdit = (e) => {
        setEditableUser({...editableUser, [e.target.name] : e.target.value})
        console.log(editableUser);
    }

    const handleUpdateUser = () =>{
        handleClose()
    }

    useEffect(() => {
        fetchUser()
    }, [])

    return (
        <div className='container'>
            <div className="row">
                <div className="col-12">
                    <table className="table">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">NAME</th>
                                <th scope="col">USERNAME</th>
                                <th scope="col">EMAIL ID</th>
                                <th scope='col'>ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                user?.map((user, index) => {
                                    return (
                                        <tr key={index}>
                                            <td>{user?.id}</td>
                                            <td>{user?.name.firstname + " " + user?.name.lastname}</td>
                                            <td>{user?.username}</td>
                                            <td>{user?.email}</td>
                                            <td>
                                                <button className="btn btn-primary me-3" onClick={() => handleEditOpen(user?.id)}>Edit</button>
                                                <button className="btn btn-danger" onClick={() => handleDelete(user?.id)}>Delete</button>
                                            </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                    <Modal show={show} onHide={handleClose}>
                        <Modal.Header closeButton>
                            <Modal.Title>Update User</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <form action="#">
                                <div class="form-group mb-3">
                                    <label for="exampleInputEmail1">First Name</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter First Name" name='firstname' value={editableUser?.name?.firstname} onChange={handleEdit}/>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="exampleInputEmail1">Last Name</label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Last Name" name='lastname' value={editableUser?.name?.lastname} onChange={handleEdit}/>
                                </div>
                                <div class="form-group mb-3">
                                    <label for="exampleInputPassword1">Username</label>
                                    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Enter Username" name='username' value={editableUser?.username} onChange={handleEdit}/>
                                </div>
                                <div class="form-group mb-4">
                                    <label for="exampleInputPassword1">Email</label>
                                    <input type="email" class="form-control" id="exampleInputPassword1" placeholder="Enter Email" name='email' value={editableUser?.email} onChange={handleEdit}/>
                                </div>
                            </form>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="secondary" onClick={handleClose}>
                                Close
                            </Button>
                            <Button variant="primary" onClick={handleUpdateUser}>
                                Save Changes
                            </Button>
                        </Modal.Footer>
                    </Modal>
                </div>
            </div>

        </div>
    )
}

export default Home
